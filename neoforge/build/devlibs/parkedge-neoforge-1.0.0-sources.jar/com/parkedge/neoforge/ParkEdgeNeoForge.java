package com.parkedge.neoforge;

import com.parkedge.ParkEdge;
import net.neoforged.fml.common.Mod;

@Mod(ParkEdge.MOD_ID)
public final class ParkEdgeNeoForge {
    public ParkEdgeNeoForge() {
        // Запуск общей инициализации для Architectury
        ParkEdge.init();
    }
}